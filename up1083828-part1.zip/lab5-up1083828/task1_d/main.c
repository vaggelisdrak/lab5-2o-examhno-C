#include <stdio.h>
#include <stdlib.h>

int myand(int a, int b);
int myor(int a, int b);
int mynor(int a, int b);
int mynand(int a, int b);
int myxor(int a, int b);

typedef int (*CallBack)(int, int);

struct logic_gate{
    char* name;
    CallBack f;
};

typedef struct logic_gate gate;

int report(gate g);

int main( ) {
    gate and = {"and gate", myand};
    gate or = {"or gate", myor};
    gate nor = {"nor gate", mynor};
    gate nand = {"nand gate", mynand};
    gate xor = {"xor gate", myxor};

    gate myfunctions[] = {and, or, nand, nor, xor};

    report(myfunctions[0]);
    printf("\n");
    report(myfunctions[1]);
    printf("\n");
    report(myfunctions[2]);
    printf("\n");
    report(myfunctions[3]);
    printf("\n");
    report(myfunctions[4]);
    return 0;
}

int myand (int a, int b) {
    return a * b;
}

int myor (int a, int b) {
    return a + b>0;
}

int mynand (int a, int b) {
    if(a*b==1){
        return 0;
    }
    else{
        return 1;
    }
}

int mynor (int a, int b) {
    if ((a+b>0) ==1){
        return 0;
    }
    else{
        return 1;
    }
}

int myxor (int a, int b) {
    if (a != b){
        return 1;
    }
    else{
        return 0;
    }
}

int report(gate g) {
    printf("%s\n",g.name);
    printf("%d %d %d\n", 0, 0, g.f(0, 0));
    printf("%d %d %d\n", 0, 1, g.f(0, 1));
    printf("%d %d %d\n", 1, 0, g.f(1, 0));
    printf("%d %d %d\n", 1, 1, g.f(1, 1));
    return 0;
}

