#include <stdio.h>
#include <stdlib.h>

int myand(int a, int b);
int myor(int a, int b);
int mynor(int a, int b);
int mynand(int a, int b);
int myxor(int a, int b);

typedef int (*CallBack)(int, int);
int report(CallBack f);

int main( ) {
    CallBack myfunctions[] = {myand, myor, myxor, mynand, mynor};

    printf("and gate\n");
    report(myfunctions[0]);

    printf("\n");
    printf("or gate\n");
    report(myfunctions[1]);

    printf("\n");
    printf("nand gate\n");
    report(myfunctions[2]);

    printf("\n");
    printf("nor gate\n");
    report(myfunctions[3]);

    printf("\n");
    printf("xor gate\n");
    report(myfunctions[4]);
    return 0;
}

int myand (int a, int b) {
    return a * b;
}

int myor (int a, int b) {
    return a + b>0;
}

int mynand (int a, int b) {
    if(a*b==1){
        return 0;
    }
    else{
        return 1;
    }
}

int mynor (int a, int b) {
    if ((a+b>0) ==1){
        return 0;
    }
    else{
        return 1;
    }
}

int myxor (int a, int b) {
    if (a != b){
        return 1;
    }
    else{
        return 0;
    }
}

int report(CallBack f) {
    printf("%d %d %d\n", 0, 0, f(0, 0));
    printf("%d %d %d\n", 0, 1, f(0, 1));
    printf("%d %d %d\n", 1, 0, f(1, 0));
    printf("%d %d %d\n", 1, 1, f(1, 1));
    return 0;
}
