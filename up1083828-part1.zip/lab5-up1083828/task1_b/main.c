#include <stdio.h>
#include <stdlib.h>
int myand(int a, int b);
int myor(int a, int b);
typedef int (*CallBack)(int, int);
int report(CallBack f);

int main( ) {
    CallBack f ;
    f = myand;
    printf("and gate\n");
    report(f);
    printf("\n");
    f = myor;
    printf("or gate\n");
    report(f);
    return 0;
}

int myand (int a, int b) {
    return a * b;
}

int myor (int a, int b) {
    return a + b>0;
}
int report(CallBack f) {
    printf("%d %d %d\n", 0, 0, f(0, 0));
    printf("%d %d %d\n", 0, 1, f(0, 1));
    printf("%d %d %d\n", 1, 0, f(1, 0));
    printf("%d %d %d\n", 1, 1, f(1, 1));
    return 0;
}
