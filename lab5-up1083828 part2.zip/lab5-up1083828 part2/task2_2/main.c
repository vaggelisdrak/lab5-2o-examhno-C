#include <stdio.h>
#include <stdlib.h>

typedef struct data {
    int value;
    struct data * next;
} Data;

typedef Data* DataList;

Data* createData(int value) {
    Data* dataptr;
    dataptr = malloc(sizeof (Data));
    dataptr->value = value;
    dataptr->next = NULL;
    return dataptr;
}

void appendData(DataList *lstptr, Data *newptr) {
    if (*lstptr == NULL) {
        *lstptr = newptr;
        return;
    }
    appendData(&((*lstptr)->next), newptr);
    return;
}

void printsequence(DataList ptr) {
    while(ptr != NULL) {
        printf("%d,", ptr->value);
        ptr = ptr->next;
    }
}

int myand(DataList ptr);
int myor(DataList ptr);
int mynor(DataList ptr);
int mynand(DataList ptr);
int myxor(DataList ptr);

typedef int (*CallBack)(DataList ptr);

struct logic_gate{
    char* name;
    CallBack f;
};

typedef struct logic_gate gate;

int report(gate g, int inputs);

void list_destroy(DataList* ptr) {
    DataList temp;
    while(*ptr != NULL) {
        temp = *ptr;
		*ptr = (*ptr)->next;
		free(temp);
    }
}

int main( ) {
    gate and = {"and gate", myand};
    gate or = {"or gate", myor};
    gate nor = {"nor gate", mynor};
    gate nand = {"nand gate", mynand};
    gate xor = {"xor gate", myxor};

    gate myfunctions[] = {and, or, nand, nor, xor};

    report(myfunctions[0],2);
    printf("\n");
    report(myfunctions[0],3);
    printf("\n");
    report(myfunctions[0],4);
    printf("\n");
    report(myfunctions[0],5);
    printf("\n");
    report(myfunctions[0],6);
    printf("\n");
    report(myfunctions[0],8);
    printf("\n");
    report(myfunctions[0],10);
    printf("\n");
    return 0;
}

int myand (DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        int b = ptr->value;
        ptr = ptr->next;
    }
    return a * b;
}

int myor (DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    return a + b>0;
}

int mynand(DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    if(a*b==1){
        return 0;
    }
    else{
        return 1;
    }
}

int mynor (DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    if ((a+b>0) ==1){
        return 0;
    }
    else{
        return 1;
    }
}

int myxor(DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    if (a != b){
        return 1;
    }
    else{
        return 0;
    }
}

int report(gate g, int inputs) {
    printf("\n%s\n", g.name);
    CallBack f = g.f;
    int pr = 1;
    int pow[inputs];
    pow[0] = 1;
    for(int i = 1; i <= inputs; i++) {
        pr *= 2;
        if(i < inputs)
            pow[i] = pr;
    }

    int c[inputs], k[inputs];
    for(int i = 0; i < inputs; i++) {
        c[i] = 0;
        k[i] = 0;
    }

    for(int rows = 0; rows < pr; rows++) {
        DataList list = NULL;
        for(int i = inputs-1; i >= 0; i--) {
            if(c[i] == pow[i] && k[i] != pow[i]) {
                Data* new;
                printf(" %d ", 1);
                new = createData(1);
                appendData(&list, new);
                if(c[i] == 2*pow[i] - 1)
                    c[i] = 0;
                else
                    k[i]++;
            }
            else {
                printf(" %d ", 0);
                Data* new = createData(0);
                appendData(&list, new);
                c[i]++;
                if(c[i] == 2*pow[i]) {
                    c[i] = pow[i];
                    k[i] = 0;
                }
            }
        }
        int x = f(list);
        printf(" %d\n", x);
        list_destroy(&list);
    }

    return 0;
}
