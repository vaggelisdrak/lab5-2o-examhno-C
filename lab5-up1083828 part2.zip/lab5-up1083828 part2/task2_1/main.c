#include <stdio.h>
#include <stdlib.h>

typedef struct data {
    int value;
    struct data * next;
} Data;

typedef Data* DataList;

Data* createData(int value) {
    Data* dataptr;
    dataptr = malloc(sizeof (Data));
    dataptr->value = value;
    dataptr->next = NULL;
    return dataptr;
}

void appendData(DataList *lstptr, Data *newptr) {
    if (*lstptr == NULL) {
        *lstptr = newptr;
        return;
    }
    appendData(&((*lstptr)->next), newptr);
    return;
}

void printsequence(DataList ptr) {
    while(ptr != NULL) {
        printf("%d,", ptr->value);
        ptr = ptr->next;
    }
}

int myand(DataList ptr);
int myor(DataList ptr);
int mynor(DataList ptr);
int mynand(DataList ptr);
int myxor(DataList ptr);

typedef int (*CallBack)(DataList ptr);

struct logic_gate{
    char* name;
    CallBack f;
};

typedef struct logic_gate gate;

int report(gate g, DataList ptr);

int main( ) {
    gate and = {"and gate", myand};
    gate or = {"or gate", myor};
    gate nor = {"nor gate", mynor};
    gate nand = {"nand gate", mynand};
    gate xor = {"xor gate", myxor};

    gate myfunctions[] = {and, or, nand, nor, xor};

    DataList ptr = NULL;
    int x = 0;
    while(x == 0 || x == 1) {
        printf("Give 1 or 0 to continue or anything else to exit: ");
        scanf("%d", &x);
        if(x == 0 || x == 1) {
            Data* new = createData(x);
            appendData(&ptr, new);
        }
    }

    printf("\n\nyour inputs: ");
    printsequence(ptr);
    printf("\n\n");

    report(myfunctions[0],ptr);
    printf("\n");
    report(myfunctions[1],ptr);
    printf("\n");
    report(myfunctions[2],ptr);
    printf("\n");
    report(myfunctions[3],ptr);
    printf("\n");
    report(myfunctions[4],ptr);
    return 0;
}

int myand (DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    return a * b;
}

int myor (DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    return a + b>0;
}

int mynand(DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    if(a*b==1){
        return 0;
    }
    else{
        return 1;
    }
}

int mynor (DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    if ((a+b>0) ==1){
        return 0;
    }
    else{
        return 1;
    }
}

int myxor(DataList ptr) {
    int b;
    int a = ptr->value;
    ptr = ptr->next;
    while(ptr!=NULL){
        b = ptr->value;
        ptr = ptr->next;
    }
    if (a != b){
        return 1;
    }
    else{
        return 0;
    }
}

int report(gate g, DataList ptr) {
    DataList p = ptr;
    printf("%s\n",g.name);
    printf("%d",g.f(p));
    return 0;
}
