#include <stdio.h>
#include <stdlib.h>

int myand(int a, int b);
int myor(int a, int b);
int mynand(int a, int b);
int mynor(int a, int b);
int myxor(int a, int b);

typedef int (*CallBack)(int, int);

typedef struct gate {
    CallBack f;
    struct gate* in1;
    struct gate* in2;
    int flag;
} Gate;

int getinput() {
    int x;
    scanf("%d", &x);
    return x;
}

Gate* creategate(CallBack f) {
    Gate* temp;
    temp = malloc(sizeof (Gate));
    temp->f = f;
    temp->in1 = NULL;
    temp->in2 = NULL;
    temp->flag = -1;
    return temp;
}

int eval(Gate* x) {
    int a, b;
    if (x->in1 != NULL)
        a = eval(x->in1);
    if (x->in2 != NULL)
        b = eval(x->in2);
    if (x->in1 == NULL && x->in2 == NULL) {
        return (x->f)(0,0);
    }
    else {
        if(x->flag == -1) {
            x->flag = (x->f)(a,b);
            return (x->f)(a,b);
        }
        else
            return x->flag;
    }

}


int main( ) {
    // NOR
    Gate *nor_ptr, *nor_b_ptr, *nor_c_ptr;
    nor_ptr = creategate(mynor);
    nor_b_ptr = creategate(getinput);
    nor_c_ptr = creategate(getinput);
    nor_ptr->in1 = nor_b_ptr;
    nor_ptr->in2 = nor_c_ptr;

    // AND
    Gate *and_ptr, *and_b_ptr,  *and_c_ptr;
    and_ptr = creategate(myand);
    and_b_ptr = creategate(getinput);
    and_c_ptr = creategate(getinput);
    and_ptr->in1 = and_b_ptr;
    and_ptr->in2 = and_c_ptr;

    // OR
    Gate *or_ptr, *or_b_ptr, *or_c_ptr;
    or_ptr = creategate(myor);
    or_b_ptr = creategate(getinput);
    or_c_ptr = creategate(getinput);
    or_ptr->in1 = or_b_ptr;
    or_ptr->in2 = or_c_ptr;

    // NAND ��� ������ ��� nor - and
    Gate *nand_ptr;
    nand_ptr = creategate(mynand);
    nand_ptr->in1 = nor_ptr;
    nand_ptr->in2 = and_ptr;

    // XOR ��� ������ ��� or - and
    Gate *xor_ptr;
    xor_ptr = creategate(myxor);
    xor_ptr->in2 = or_ptr;
    xor_ptr->in1 = and_ptr;


    // OR ��� ������ ��� nand - xor
    Gate *or_final;
    or_final = creategate(myor);
    or_final->in1 = nand_ptr;
    or_final->in2 = xor_ptr;
    printf("%d!!!\n", eval(or_final));

    return 0;
}



int myand(int a, int b) {
    return a * b;
}

int myor(int a, int b) {
    return a + b>0;
}

int mynand(int a, int b){
    return !(a * b);
}

int mynor(int a, int b) {
    return !(a + b>0);
}

int myxor(int a, int b) {
    return (a * !b) + (!a * b);
}



